/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatapplogin;
import java.util.Scanner;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class MessageTest {
    @TempDir
    Path tempDir;
 
    // Test data from the brief. Message IDs are fixed here so the hashes are predictable.
    private Message message1;   // Test Case 1: sent
    private Message message2;   // Test Case 2: disregarded
 
    @BeforeEach
    public void setUp() {
        Message.clearMessages();
        Message.setStorageFile(tempDir.resolve("messages.json"));
        message1 = new Message("0012345678", 0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        message2 = new Message("0987654321", 1, "08575975889", "Hi Keegan, did you receive the payment?");
    }
 
    // ---------- assertEquals ----------
    @Test
    public void testMessageNotMoreThan250Characters() {
        assertEquals("Message ready to send.", Message.checkMessageLength("Hi Mike, can you join us for dinner tonight?"));
        assertEquals("Message ready to send.", Message.checkMessageLength("a".repeat(250)));
    }
 
    @Test
    public void testMessageMoreThan250Characters() {
        String tooLong = "a".repeat(300);
        assertEquals("Message exceeds 250 characters by 50; please reduce the size.", Message.checkMessageLength(tooLong));
    }
 
    @Test
    public void testRecipientCorrectlyFormatted() {
        assertEquals("Cell phone number successfully captured.", message1.checkRecipientCell());
    }
 
    @Test
    public void testRecipientIncorrectlyFormatted() {
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                message2.checkRecipientCell());
    }
 
    @Test
    public void testMessageHashTestCase1() {
        assertEquals("00:0:HITONIGHT", message1.createMessageHash());
    }
 
    @Test
    public void testMessageHashesInLoop() {
        // { message ID, message number, message text, expected hash }
        String[][] cases = {
            {"0012345678", "0", "Hi Mike, can you join us for dinner tonight?", "00:0:HITONIGHT"},
            {"0987654321", "1", "Hi Keegan, did you receive the payment?", "09:1:HIPAYMENT"},
            {"0055555555", "2", "Hi thanks", "00:2:HITHANKS"},
            {"1234567890", "3", "Hello", "12:3:HELLOHELLO"}
        };
        for (String[] c : cases) {
            Message m = new Message(c[0], Integer.parseInt(c[1]), "+27718693002", c[2]);
            assertEquals(c[3], m.createMessageHash());
        }
    }
 
    @Test
    public void testMessageIDCreated() {
        String id = Message.generateMessageID();
        Message m = new Message(id, 0, "+27718693002", "Hi");
        assertEquals("Message ID generated: " + id, m.getMessageIDMessage());
    }
 
    @Test
    public void testMessageSentOptions() {
        assertEquals("Message successfully sent.", message1.SentMessage(1));
        assertEquals("Press 0 to delete the message.", message2.SentMessage(2));
        assertEquals("Message successfully stored.", message1.SentMessage(3));
    }
 
    // ---------- assertTrue / assertFalse ----------
    @Test
    public void testMessageIDIsNoMoreThanTenCharacters() {
        assertTrue(message1.checkMessageID());
        assertTrue(new Message(Message.generateMessageID(), 0, "+27718693002", "Hi").checkMessageID());
        assertFalse(new Message("12345678901", 0, "+27718693002", "Hi").checkMessageID());
    }
 
    @Test
    public void testTotalMessagesSent() {
        message1.SentMessage(1);   // Test Case 1: Select Send
        message2.SentMessage(2);   // Test Case 2: Select Disregard
        assertEquals(1, Message.returnTotalMessages());
    }
 
    @Test
    public void testPrintMessagesShowsDetailsInOrder() {
        message1.SentMessage(1);
        String output = Message.printMessages();
        int id = output.indexOf("Message ID: 0012345678");
        int hash = output.indexOf("Message Hash: 00:0:HITONIGHT");
        int recipient = output.indexOf("Recipient: +27718693002");
        int text = output.indexOf("Message: Hi Mike, can you join us for dinner tonight?");
        assertTrue(id >= 0 && id < hash && hash < recipient && recipient < text);
    }
 
    @Test
    public void testStoreMessageWritesJson() throws IOException {
        assertTrue(message1.storeMessage());
        String json = Files.readString(tempDir.resolve("messages.json"), StandardCharsets.UTF_8);
        assertTrue(json.contains("\"messageHash\": \"00:0:HITONIGHT\""));
        assertTrue(json.contains("\"recipient\": \"+27718693002\""));
    }
}

    
    