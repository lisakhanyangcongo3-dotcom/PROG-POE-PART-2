/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatapplogin;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class ChatappLoginTest {
    
    // Registered user used for the login-related tests (test data from the brief)
    private final ChatappLogin user = new ChatappLogin("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
 
    // ---------- assertEquals ----------
    @Test
    public void testUsernameCorrectlyFormatted() {
        String expected = "Welcome Kyle, Smith it is great to see you again.";
        boolean loggedIn = user.loginUser("kyl_1", "Ch&&sec@ke99!");
        assertEquals(expected, user.returnLoginStatus(loggedIn));
    }
 
    @Test
    public void testUsernameIncorrectlyFormatted() {
        ChatappLogin bad = new ChatappLogin("Kyle", "Smith", "kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976");
        String expected = "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        assertEquals(expected, bad.getUsernameMessage());
    }
 
    @Test
    public void testPasswordMeetsComplexity() {
        ChatappLogin ok = new ChatappLogin("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals("Password successfully captured.", ok.getPasswordMessage());
    }
 
    @Test
    public void testPasswordDoesNotMeetComplexity() {
        ChatappLogin bad = new ChatappLogin("Kyle", "Smith", "kyl_1", "password", "+27838968976");
        String expected = "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        assertEquals(expected, bad.getPasswordMessage());
    }
 
    @Test
    public void testCellPhoneIncorrectlyFormattedMessage() {
        ChatappLogin bad = new ChatappLogin("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "08966553");
        String expected = "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        assertEquals(expected, bad.getCellPhoneMessage());
    }
 
    // ---------- assertTrue / assertFalse ----------
    @Test
    public void testLoginSuccessful() {
        assertTrue(user.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }
 
    @Test
    public void testLoginFailed() {
        assertFalse(user.loginUser("kyl_1", "wrongPass1!"));
    }
 
    @Test
    public void testUsernameCorrectlyFormattedBoolean() {
        assertTrue(user.checkUserName());
    }
 
    @Test
    public void testUsernameIncorrectlyFormattedBoolean() {
        ChatappLogin bad = new ChatappLogin("Kyle", "Smith", "kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976");
        assertFalse(bad.checkUserName());
    }
 
    @Test
    public void testPasswordMeetsComplexityBoolean() {
        assertTrue(user.checkPasswordComplexity());
    }
 
    @Test
    public void testPasswordDoesNotMeetComplexityBoolean() {
        ChatappLogin bad = new ChatappLogin("Kyle", "Smith", "kyl_1", "password", "+27838968976");
        assertFalse(bad.checkPasswordComplexity());
    }
 
    @Test
    public void testCellPhoneCorrectlyFormatted() {
        assertTrue(user.checkCellPhoneNumber());
    }
 
    @Test
    public void testCellPhoneIncorrectlyFormatted() {
        ChatappLogin bad = new ChatappLogin("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "08966553");
        assertFalse(bad.checkCellPhoneNumber());
    }
}
