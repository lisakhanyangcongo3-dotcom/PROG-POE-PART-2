/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapplogin;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class ChatApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
 
        System.out.println("===== Chat App: Registration =====");
        
        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine().trim();
        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine().trim();
 
        // Username: keep asking until it is correctly formatted.
        String username;
        ChatappLogin check;
        do {
            System.out.print("Enter a username (underscore, max 5 characters): ");
            username = scanner.nextLine().trim();
            check = new ChatappLogin(firstName, lastName, username, "", "");
            System.out.println(check.getUsernameMessage());
        } while (!check.checkUserName());
 
        // Password: keep asking until it meets the complexity requirements.
        String password;
        do {
            System.out.print("Enter a password: ");
            password = scanner.nextLine();
            check = new ChatappLogin(firstName, lastName, username, password, "");
            System.out.println(check.getPasswordMessage());
        } while (!check.checkPasswordComplexity());
 
        // Cell phone number: keep asking until it is valid.
        String cell;
        do {
            System.out.print("Enter your cell phone number (e.g. +27831234567): ");
            cell = scanner.nextLine().trim();
            check = new ChatappLogin(firstName, lastName, username, password, cell);
            System.out.println(check.getCellPhoneMessage());
        } while (!check.checkCellPhoneNumber());
 
        ChatappLogin user = new ChatappLogin(firstName, lastName, username, password, cell);
        System.out.println(user.registerUser());
 
        // Login: keep asking until the details match.
        System.out.println("\n=== Chat App: Login ===");
        boolean loggedIn;
        do {
            System.out.print("Username: ");
            String enteredUser = scanner.nextLine().trim();
            System.out.print("Password: ");
            String enteredPass = scanner.nextLine();
            loggedIn = user.loginUser(enteredUser, enteredPass);
            System.out.println(user.returnLoginStatus(loggedIn));
        } while (!loggedIn);
        System.out.println("\nWelcome to QuickChat."); //[cite: 12]
        boolean running = true;
        Message msgHandler = new Message(); 

        while (running) {
            System.out.println("\nSelect an option:");
            System.out.println("1) Send Messages"); //[cite: 12]
            System.out.println("2) Show recently sent messages"); //[cite: 12]
            System.out.println("3) Quit"); //[cite: 12]
            System.out.print("Choice: ");
            
            String menuChoice = scanner.nextLine().trim();

            if (menuChoice.equals("1")) {
                System.out.print("How many messages do you wish to enter? "); //[cite: 13]
                int numMessages = Integer.parseInt(scanner.nextLine().trim());

                // Application allows the user to enter only the set number of messages[cite: 13]
                for (int i = 1; i <= numMessages; i++) {
                    Message currentMsg = new Message();
                    currentMsg.setMessageNumber(i);
                    currentMsg.setMessageID(currentMsg.generateMessageID());

                    System.out.print("\nEnter recipient cell number (Max 10 chars, starts with +): ");
                    String cellRecipient = scanner.nextLine().trim();
                    
                    while (!currentMsg.checkRecipientCell(cellRecipient)) {
                        System.out.print("Invalid format. Re-enter recipient cell number: ");
                        cellRecipient = scanner.nextLine().trim();
                    }
                    currentMsg.setRecipientCell(cellRecipient);

                    System.out.print("Enter your message (Max 250 chars): ");
                    String text = scanner.nextLine().trim();
                    
                    String lengthCheck = currentMsg.checkMessageLength(text);
                    while (!lengthCheck.equals("Message sent")) {
                        System.out.println(lengthCheck); //[cite: 15]
                        System.out.print("Enter your message: ");
                        text = scanner.nextLine().trim();
                        lengthCheck = currentMsg.checkMessageLength(text);
                    }
                    currentMsg.setMessageText(text);

                    currentMsg.setMessageHash(currentMsg.createMessageHash(
                            currentMsg.getMessageID(), i, text));

                    System.out.println("\nMessage complete. Choose an option:");
                    System.out.println("1 - Send Message");
                    System.out.println("2 - Store Message to send later");
                    System.out.println("3 - Disregard Message");
                    System.out.print("Choice: ");
                    int actionChoice = Integer.parseInt(scanner.nextLine().trim());

                    // Output success/store/disregard string based on choice[cite: 16, 17]
                    System.out.println(currentMsg.SentMessage(actionChoice, currentMsg));

                    if (actionChoice == 1) {
                        // Display full details on screen after sending[cite: 17]
                        System.out.println("\n--- Message Details ---");
                        System.out.println("Message ID: " + currentMsg.getMessageID());
                        System.out.println("Message Hash: " + currentMsg.getMessageHash());
                        System.out.println("Recipient: " + currentMsg.getRecipientCell());
                        System.out.println("Message: " + currentMsg.getMessageText());
                    } else if (actionChoice == 3) {
                        System.out.println("Message deleted. Press 0 to confirm."); //[cite: 17]
                        scanner.nextLine();
                    }
                }
                
                // Total number of messages accumulated and displayed once all messages sent[cite: 17]
                System.out.println("\nTotal messages sent in this session: " + msgHandler.returnTotalMessagess());

            } else if (menuChoice.equals("2")) {
                System.out.println("Coming Soon."); //[cite: 12]
            } else if (menuChoice.equals("3")) {
                running = false; // Application should run until the user selects 'quit'[cite: 13]
            } else {
                System.out.println("Invalid option. Please try again.");
            }
        }
 
        scanner.close();
    }
}
    

