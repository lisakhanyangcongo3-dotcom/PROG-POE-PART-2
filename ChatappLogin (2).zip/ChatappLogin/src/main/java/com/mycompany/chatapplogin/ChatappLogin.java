/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapplogin;

import java.util.regex.Pattern;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class ChatappLogin {
    public static void main(String[] args) {
        
    }
     private static final String USERNAME_OK = "Username successfully captured.";
     private static final String USERNAME_BAD = "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
     private static final String PASSWORD_OK = "Password successfully captured.";
     private static final String PASSWORD_BAD = "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
     private static final String CELL_OK = "Cell phone number successfully added.";
     private static final String CELL_BAD = "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
     private static final String LOGIN_FAIL = "Username or password incorrect, please try again.";
 
    
    private static final Pattern CELL_PATTERN = Pattern.compile("^\\+\\d{1,3}\\d{1,10}$");
 
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellPhone;
 
    public ChatappLogin(String firstName, String lastName, String username, String password, String cellPhone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhone = cellPhone;
    }
 
    // Username must contain an underscore and be no more than five characters long.
    public boolean checkUserName() {
        return username != null && username.contains("_") && username.length() <= 5;
    }
 
    // Password: at least 8 characters, a capital letter, a number and a special character.
    public boolean checkPasswordComplexity() {
        if (password == null || password.length() < 8) {
            return false;
        }
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (!Character.isLetter(c)) {
                hasSpecial = true;
            }
        }
        return hasCapital && hasNumber && hasSpecial;
    }
 
    // Cell number must have the international code followed by a number of no more than ten digits.
    public boolean checkCellPhoneNumber() {
        return cellPhone != null && CELL_PATTERN.matcher(cellPhone).matches();
    }
    public static boolean isValidCellNumber(String number) {
    return number != null && number.matches("^\\+\\d{1,3}\\d{1,10}$");
}
 
    // Feedback messages (used by registerUser and the unit tests).
    public String getUsernameMessage() {
        return checkUserName() ? USERNAME_OK : USERNAME_BAD;
    }
 
    public String getPasswordMessage() {
        return checkPasswordComplexity() ? PASSWORD_OK : PASSWORD_BAD;
    }
 
    public String getCellPhoneMessage() {
        return checkCellPhoneNumber() ? CELL_OK : CELL_BAD;
    }
 
    // Returns the registration messaging for the username/password rules.
    public String registerUser() {
        boolean userOk = checkUserName();
        boolean passOk = checkPasswordComplexity();
 
        if (!userOk && !passOk) {
            return USERNAME_BAD + "\n" + PASSWORD_BAD;
        } else if (!userOk) {
            return USERNAME_BAD;
        } else if (!passOk) {
            return PASSWORD_BAD;
        }
        return USERNAME_OK + "\n" + PASSWORD_OK + "\nUser has been registered successfully.";
    }
 
    // Verifies the login details match those stored at registration.
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return username != null && password != null
                && username.equals(enteredUsername)
                && password.equals(enteredPassword);
    }
 
    // Returns the messaging for a successful or failed login.
    public String returnLoginStatus(boolean loginSuccessful) {
        if (loginSuccessful) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        }
        return LOGIN_FAIL;
    }
}
        
    

