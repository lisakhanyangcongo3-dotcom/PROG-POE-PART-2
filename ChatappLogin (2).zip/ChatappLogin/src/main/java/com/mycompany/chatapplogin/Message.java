/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapplogin;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Message {
    private String messageID;
    private String recipientCell;
    private String messageText;
    private String messageHash;
    private int messageNumber;
    
    private static int totalMessagesSent = 0;
    private static List<Message> sessionMessages = new ArrayList<>();

    public String generateMessageID() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }

    public boolean checkMessageID(String id) {
        return id != null && id.length() <= 10;
    }

    public boolean checkRecipientCell(String cellNumber) {
        return cellNumber != null && cellNumber.length() <= 10 && cellNumber.startsWith("+");
    }

    public String checkMessageLength(String message) {
        if (message.length() > 250) {
            return "Please enter a message of less than 250 characters.";
        }
        return "Message sent";
    }

    public String createMessageHash(String id, int msgNum, String text) {
        String firstTwoId = id.length() >= 2 ? id.substring(0, 2) : id;
        
        String[] words = text.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        
        String hash = firstTwoId + ":" + msgNum + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }

    public String SentMessage(int choice, Message msg) {
        switch (choice) {
            case 1:
                totalMessagesSent++;
                sessionMessages.add(msg);
                return "Message successfully sent";
            case 2:
                storeMessage(msg);
                return "Message successfully stored";
            case 3:
                return "Press 0 to delete the message";
            default:
                return "Invalid option";
        }
    }

    public void storeMessage(Message msg) {
        try (FileWriter file = new FileWriter("messages.json", true)) {
            String jsonBuilder = "{\n" +
                    "  \"MessageID\": \"" + msg.getMessageID() + "\",\n" +
                    "  \"MessageHash\": \"" + msg.getMessageHash() + "\",\n" +
                    "  \"Recipient\": \"" + msg.getRecipientCell() + "\",\n" +
                    "  \"Message\": \"" + msg.getMessageText() + "\"\n" +
                    "}\n";
            file.write(jsonBuilder);
        } catch (IOException e) {
            System.out.println("Error writing to JSON file.");
        }
    }

    public String printMessages() {
        if (sessionMessages.isEmpty()) return "No messages sent yet.";
        
        StringBuilder allMessages = new StringBuilder();
        for (Message msg : sessionMessages) {
            allMessages.append("Message ID: ").append(msg.getMessageID()).append("\n")
                       .append("Message Hash: ").append(msg.getMessageHash()).append("\n")
                       .append("Recipient: ").append(msg.getRecipientCell()).append("\n")
                       .append("Message: ").append(msg.getMessageText()).append("\n\n");
        }
        return allMessages.toString();
    }

    public int returnTotalMessagess() {
        return totalMessagesSent;
    }

    // Getters and Setters
    public void setMessageID(String messageID) { this.messageID = messageID; }
    public String getMessageID() { return messageID; }
    
    public void setRecipientCell(String recipientCell) { this.recipientCell = recipientCell; }
    public String getRecipientCell() { return recipientCell; }
    
    public void setMessageText(String messageText) { this.messageText = messageText; }
    public String getMessageText() { return messageText; }
    
    public void setMessageHash(String messageHash) { this.messageHash = messageHash; }
    public String getMessageHash() { return messageHash; }
    
    public void setMessageNumber(int messageNumber) { this.messageNumber = messageNumber; }
}

